import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Crops table for crop data
export const crops = pgTable("crops", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  imageUrl: text("image_url").notNull(),
  waterNeeds: text("water_needs").notNull(),
  growingPeriod: text("growing_period").notNull(),
  bestPlanting: text("best_planting").notNull(),
  description: text("description")
});

export const insertCropSchema = createInsertSchema(crops).pick({
  name: true,
  imageUrl: true,
  waterNeeds: true,
  growingPeriod: true,
  bestPlanting: true,
  description: true
});

// Weather data table
export const weatherData = pgTable("weather_data", {
  id: serial("id").primaryKey(),
  region: text("region").notNull(),
  date: text("date").notNull(),
  temperature: integer("temperature").notNull(),
  condition: text("condition").notNull(),
  humidity: integer("humidity").notNull(),
  precipitation: integer("precipitation").notNull(),
  windSpeed: text("wind_speed")
});

export const insertWeatherDataSchema = createInsertSchema(weatherData).pick({
  region: true,
  date: true,
  temperature: true,
  condition: true,
  humidity: true,
  precipitation: true,
  windSpeed: true
});

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  message: text("message").notNull(),
  response: text("response").notNull(),
  timestamp: text("timestamp").notNull(),
  metadata: jsonb("metadata")
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  userId: true,
  message: true,
  response: true,
  timestamp: true,
  metadata: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCrop = z.infer<typeof insertCropSchema>;
export type Crop = typeof crops.$inferSelect;

export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;
export type WeatherData = typeof weatherData.$inferSelect;

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

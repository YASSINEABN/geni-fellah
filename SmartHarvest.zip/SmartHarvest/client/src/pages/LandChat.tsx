import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { SelectedLand } from "@/lib/types";
import Footer from "@/components/Footer";
import TypingAnimation from "@/components/TypingAnimation";

interface Message {
  id: string;
  sender: "user" | "assistant";
  content: string;
}

export default function LandChat() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split("?")[1]);
  
  const [landInfo, setLandInfo] = useState<SelectedLand>({
    region: params.get("region") || "Souss-Massa, Morocco",
    surfaceArea: params.get("area") || "5.2 hectares",
    soilType: params.get("soil") || "Loamy with good drainage",
  });
  
  const [selectedCrop, setSelectedCrop] = useState(params.get("crop") || "Tomatoes");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      sender: "assistant",
      content: `مرحبا بك فالمساعد الفلاحي ديالك! كتشوف عندك أرض فـ ${landInfo.region}، المساحة ديالها هي ${landInfo.surfaceArea} وعندك تربة من نوع ${landInfo.soilType}، اللي مزيانة باش تزرع ${selectedCrop}. كيفاش نقدر نعاونك باش تطور الفلاحة ديالك اليوم؟`
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Scroll to bottom on new messages
    const messagesContainer = document.getElementById("chat-messages");
    if (messagesContainer) {
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      sender: "user",
      content: input
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    
    try {
      const response = await apiRequest("POST", "/api/chat", {
        message: input,
        land: landInfo,
        crop: selectedCrop
      });
      
      const responseData = await response.json();
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        content: responseData.response
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error sending message:", error);
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        content: "I'm sorry, I encountered an error processing your request. Please try again later."
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const suggestedQuestions = [
    "How much water do I need?",
    "When is the best planting time?",
    "What pests should I watch for?",
    "How do I improve soil fertility?",
    "When should I harvest?",
    "Current market prices?"
  ];

  return (
    <div className="grain-texture min-h-screen flex flex-col">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="mb-8">
          <Button 
            onClick={() => window.location.href = "/"} 
            className="flex items-center text-white bg-secondary hover:bg-secondary-light transition"
          >
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Land Selection
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <Card className="bg-white rounded-xl shadow-md overflow-hidden h-full">
              <CardHeader className="border-b border-accent p-4 bg-primary text-white">
                <CardTitle className="font-heading font-semibold text-xl">Your Land Details</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-heading font-medium text-primary">Region</h3>
                    <p className="text-secondary">{landInfo.region}</p>
                  </div>
                  <div>
                    <h3 className="font-heading font-medium text-primary">Surface Area</h3>
                    <p className="text-secondary">{landInfo.surfaceArea}</p>
                  </div>
                  <div>
                    <h3 className="font-heading font-medium text-primary">Soil Type</h3>
                    <p className="text-secondary">{landInfo.soilType}</p>
                  </div>
                  <div>
                    <h3 className="font-heading font-medium text-primary">Selected Crop</h3>
                    <p className="text-secondary">{selectedCrop}</p>
                  </div>
                  
                  <div className="border-t border-accent pt-4 mt-6">
                    <h3 className="font-heading font-medium text-primary mb-2">Change Crop</h3>
                    <div className="flex flex-wrap gap-2">
                      {["Tomatoes", "Citrus", "Olives"].map((crop) => (
                        <Button
                          key={crop}
                          variant={selectedCrop === crop ? "default" : "outline"}
                          onClick={() => setSelectedCrop(crop)}
                          className={
                            selectedCrop === crop 
                              ? "bg-primary text-white" 
                              : "bg-white text-secondary border-accent"
                          }
                        >
                          {crop}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="md:col-span-2" >
            <Card className="bg-white rounded-xl shadow-md overflow-hidden h-[calc(100vh-12rem)]">
              <CardHeader className="border-b border-accent p-4 bg-primary text-white h-[5rem]">
                <CardTitle className="font-heading font-semibold text-xl flex items-center">
                  <i className="ri-robot-line mr-2"></i>
                  Agricultural Assistant
                </CardTitle>
                <p className="text-white text-opacity-80">
                  Personalized advice for your {landInfo.surfaceArea} of {selectedCrop} in {landInfo.region}
                </p>
              </CardHeader>
              <CardContent className="flex flex-col h-[calc(100%-8rem)] p-0">
                <div className="flex-grow overflow-y-auto p-4 custom-scrollbar" id="chat-messages">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div key={message.id} className="flex items-start">
                        <div className={`${
                          message.sender === "user" 
                            ? "bg-primary text-white rounded-lg p-3 ml-auto" 
                            : "bg-accent text-primary rounded-lg p-3 mr-auto"
                        } max-w-[80%]`}>
                          {message.sender === "user" ? (
                            <p dangerouslySetInnerHTML={{__html: message.content.replace(/\n/g, '<br>')}} />
                          ) : (
                            message.content === messages[0].content ? (
                              <p dangerouslySetInnerHTML={{__html: message.content.replace(/\n/g, '<br>')}} />
                            ) : (
                              <TypingAnimation message={message.content} typingSpeed={20} />
                            )
                          )}
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex items-start">
                        <div className="bg-accent text-primary rounded-lg p-3 mr-auto max-w-[80%]">
                          <div className="flex space-x-2">
                            <div className="w-2 h-2 rounded-full bg-primary animate-bounce"></div>
                            <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                            <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "0.4s" }}></div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <div className="p-4 border-t border-accent mt-auto">
                  <form className="flex gap-2" onSubmit={handleSendMessage}>
                    <Input 
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Ask about crops, irrigation, or farming techniques..." 
                      className="flex-grow px-4 py-2 rounded-lg border border-accent focus:outline-none focus:border-primary transition"
                      disabled={isLoading}
                    />
                    <Button 
                      type="submit" 
                      disabled={isLoading}
                      className="bg-primary hover:bg-primary-dark text-white rounded-lg px-4 py-2 transition flex items-center"
                    >
                      <i className="ri-send-plane-fill"></i>
                    </Button>
                  </form>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {suggestedQuestions.map((question, index) => (
                      <Button
                        key={index}
                        type="button"
                        variant="outline"
                        onClick={() => setInput(question)}
                        className="bg-accent text-primary text-xs px-3 py-1 rounded-full hover:bg-accent-foreground/20 transition"
                      >
                        {question}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
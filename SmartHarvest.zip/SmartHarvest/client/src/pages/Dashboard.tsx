import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SimpleMapSelector from "@/components/SimpleMapSelector";
import TypingAnimation from "@/components/TypingAnimation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { SelectedLand } from "@/lib/types";

interface Message {
  id: string;
  sender: "user" | "assistant";
  content: string;
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      sender: "assistant",
      content: "Welcome to Geni Fellah, your smart agricultural assistant! I can help you select the right crops for your land, provide irrigation advice, or answer questions about farming techniques. Please draw your land on the map or chat with me to get started."
    }
  ]);
  
  const [selectedLand, setSelectedLand] = useState<SelectedLand>({
    region: "Souss-Massa, Morocco",
    surfaceArea: "0 hectares",
    soilType: "Loamy with good drainage"
  });
  
  const [selectedCrop, setSelectedCrop] = useState("Tomatoes");
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showMap, setShowMap] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Scroll to bottom on new messages
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      sender: "user",
      content: input
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    
    try {
      // General chatbot doesn't need land-specific details
      const response = await apiRequest("POST", "/api/chat", {
        message: input,
        land: { region: "General", surfaceArea: "N/A", soilType: "N/A" },
        crop: "General"
      });
      
      const responseData = await response.json();
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        content: responseData.response
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error sending message:", error);
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        content: "I'm sorry, I encountered an error processing your request. Please try again later."
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleMapSelection = () => {
    // This function will be called when the user clicks the "Consult Your Expert" button
    if (selectedLand.surfaceArea === "0 hectares") return;
    
    // Navigate to the land-specific chat with the selected parameters
    const params = new URLSearchParams();
    params.set("region", selectedLand.region);
    params.set("area", selectedLand.surfaceArea);
    params.set("soil", selectedLand.soilType);
    
    // Set the crop based on the detected region
    let crop = "Tomatoes";
    if (selectedLand.region.includes("Marrakech")) {
      crop = "Citrus";
    } else if (selectedLand.region.includes("Tangier")) {
      crop = "Olives";
    }
    params.set("crop", crop);
    
    setLocation(`/land-chat?${params.toString()}`);
  };

  const suggestedQuestions = [
    "What crops grow best in Morocco?",
    "How much water do tomatoes need?",
    "When to plant citrus trees?",
    "How to prevent common pests?"
  ];

  return (
    <div className="grain-texture min-h-screen flex flex-col">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        <section className="mb-10">
          <div className="bg-gradient-to-r from-primary to-primary-light rounded-xl shadow-lg overflow-hidden">
            <div className="md:flex">
              <div className="p-8 md:w-2/3">
                <h2 className="font-heading text-3xl md:text-4xl font-bold text-white mb-4">
                  Geni Fellah - Smart Agricultural Assistant
                </h2>
                <p className="text-accent text-lg mb-6">
                  Combining AI, geospatial technology, and agricultural expertise to deliver intelligent insights for your farm.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button 
                    onClick={() => setShowMap(true)}
                    className="bg-white text-primary hover:bg-accent hover:text-primary-dark font-medium px-6 py-2 rounded-full shadow-md flex items-center"
                  >
                    <i className="ri-map-pin-line mr-2"></i> Draw Your Land
                  </Button>
                  <Button 
                    onClick={() => setShowMap(false)}
                    className="bg-secondary hover:bg-secondary-light text-white font-medium px-6 py-2 rounded-full shadow-md flex items-center"
                  >
                    <i className="ri-robot-line mr-2"></i> Get General Advice
                  </Button>
                </div>
              </div>
              <div className="md:w-1/3 relative h-64 md:h-auto overflow-hidden">
                <img 
                  src="https://img.lovepik.com/photo/20211208/medium/lovepik-farmer-plowing-happy-smile-in-wheat-field-picture_501611484.jpg" 
                  alt="Modern agricultural field" 
                  className="absolute inset-0 w-full h-full object-cover" 
                />
              </div>
            </div>
          </div>
        </section>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-10">
          {/* Left Column (2/3 width on large screens) */}
          <div className="lg:col-span-2">
            {showMap ? (
              <SimpleMapSelector 
                selectedLand={selectedLand} 
                setSelectedLand={setSelectedLand}
                onMapSelection={handleMapSelection}
              />
            ) : (
              <Card className="bg-white rounded-xl shadow-md overflow-hidden">
                <CardHeader className="border-b border-accent p-4">
                  <CardTitle className="font-heading font-semibold text-xl text-primary">General Agricultural Information</CardTitle>
                  <p className="text-secondary text-sm">Learn about farming practices and techniques in Morocco</p>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-6">
                    <div className="bg-accent rounded-lg p-4">
                      <h3 className="font-heading font-semibold text-primary text-lg mb-2">Agricultural Regions of Morocco</h3>
                      <p className="text-secondary mb-4">
                        Morocco has diverse agricultural zones, each with unique characteristics:
                      </p>
                      <ul className="space-y-2 text-secondary">
                        <li className="flex items-start">
                          <i className="ri-check-line text-primary mt-1 mr-2"></i>
                          <span><strong>Souss-Massa:</strong> Known for citrus, vegetables, and early season crops. Mild climate with good water resources.</span>
                        </li>
                        <li className="flex items-start">
                          <i className="ri-check-line text-primary mt-1 mr-2"></i>
                          <span><strong>Marrakech-Safi:</strong> Famous for olives, citrus, and cereals. Hot summers and mild winters.</span>
                        </li>
                        <li className="flex items-start">
                          <i className="ri-check-line text-primary mt-1 mr-2"></i>
                          <span><strong>Tangier-Tétouan:</strong> Ideal for olives, vegetables, and legumes. Higher rainfall and moderate temperatures.</span>
                        </li>
                      </ul>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-white border border-accent rounded-lg p-4">
                        <h3 className="font-heading font-semibold text-primary text-lg mb-2">Common Crops</h3>
                        <ul className="space-y-1 text-secondary">
                          <li className="flex items-center">
                            <i className="ri-plant-line text-primary mr-2"></i>
                            <span>Cereals (wheat, barley)</span>
                          </li>
                          <li className="flex items-center">
                            <i className="ri-plant-line text-primary mr-2"></i>
                            <span>Citrus fruits (oranges, lemons)</span>
                          </li>
                          <li className="flex items-center">
                            <i className="ri-plant-line text-primary mr-2"></i>
                            <span>Olives and olive oil</span>
                          </li>
                          <li className="flex items-center">
                            <i className="ri-plant-line text-primary mr-2"></i>
                            <span>Vegetables (tomatoes, peppers)</span>
                          </li>
                          <li className="flex items-center">
                            <i className="ri-plant-line text-primary mr-2"></i>
                            <span>Dates, almonds, and other tree crops</span>
                          </li>
                        </ul>
                      </div>
                      
                      <div className="bg-white border border-accent rounded-lg p-4">
                        <h3 className="font-heading font-semibold text-primary text-lg mb-2">Irrigation Methods</h3>
                        <ul className="space-y-1 text-secondary">
                          <li className="flex items-center">
                            <i className="ri-water-flash-line text-primary mr-2"></i>
                            <span>Drip irrigation (water efficient)</span>
                          </li>
                          <li className="flex items-center">
                            <i className="ri-water-flash-line text-primary mr-2"></i>
                            <span>Sprinkler systems</span>
                          </li>
                          <li className="flex items-center">
                            <i className="ri-water-flash-line text-primary mr-2"></i>
                            <span>Surface irrigation (traditional)</span>
                          </li>
                          <li className="flex items-center">
                            <i className="ri-water-flash-line text-primary mr-2"></i>
                            <span>Subsurface irrigation</span>
                          </li>
                          <li className="flex items-center">
                            <i className="ri-water-flash-line text-primary mr-2"></i>
                            <span>Rainwater harvesting techniques</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex justify-center">
                      <Button 
                        onClick={() => setShowMap(true)}
                        className="bg-primary hover:bg-primary-dark text-white font-medium px-6 py-2 rounded-full shadow-md flex items-center"
                      >
                        <i className="ri-map-pin-line mr-2"></i>
                        Draw Your Land for Personalized Advice
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
          
          {/* Right Column (1/3 width on large screens) */}
          <div>
            <Card className="bg-white rounded-xl shadow-md overflow-hidden h-[calc(100vh-18rem)] min-h-[500px] flex flex-col">
              <CardHeader className="border-b border-accent p-4">
                <CardTitle className="font-heading font-semibold text-xl text-primary flex items-center">
                  <i className="ri-robot-line mr-2 text-destructive"></i>
                  Chat with Geni Fellah
                </CardTitle>
                <p className="text-secondary text-sm">Your general agricultural assistant</p>
              </CardHeader>
              <CardContent className="flex-grow p-4 overflow-y-auto custom-scrollbar" id="chat-messages">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div key={message.id} className="flex items-start">
                      <div className={`${
                        message.sender === "user" 
                          ? "bg-primary text-white rounded-lg p-3 ml-auto" 
                          : "bg-accent text-secondary rounded-lg p-3 mr-auto"
                      } max-w-[80%]`}>
                        {message.sender === "user" ? (
                          <p dangerouslySetInnerHTML={{__html: message.content.replace(/\n/g, '<br>')}} />
                        ) : (
                          message.content === messages[0].content ? (
                            <p dangerouslySetInnerHTML={{__html: message.content.replace(/\n/g, '<br>')}} />
                          ) : (
                            <TypingAnimation message={message.content} typingSpeed={25} />
                          )
                        )}
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex items-start">
                      <div className="bg-accent text-secondary rounded-lg p-3 mr-auto max-w-[80%]">
                        <div className="flex space-x-2">
                          <div className="w-2 h-2 rounded-full bg-secondary animate-bounce"></div>
                          <div className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                          <div className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "0.4s" }}></div>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </CardContent>
              <div className="p-4 border-t border-accent">
                <form className="flex gap-2" onSubmit={handleSendMessage}>
                  <Input 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask about crops, irrigation, or farming techniques..." 
                    className="flex-grow px-4 py-2 rounded-lg border border-accent focus:outline-none focus:border-primary transition"
                    disabled={isLoading}
                  />
                  <Button 
                    type="submit" 
                    disabled={isLoading}
                    className="bg-primary hover:bg-primary-dark text-white rounded-lg px-4 py-2 transition flex items-center"
                  >
                    <i className="ri-send-plane-fill"></i>
                  </Button>
                </form>
                <div className="mt-2 flex flex-wrap gap-2">
                  {suggestedQuestions.map((question, index) => (
                    <Button
                      key={index}
                      type="button"
                      variant="outline"
                      onClick={() => setInput(question)}
                      className="bg-accent text-secondary text-xs px-3 py-1 rounded-full hover:bg-accent-foreground/20 transition"
                    >
                      {question}
                    </Button>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { fetchRecommendedCrops } from "@/lib/api";
import { SelectedLand } from "@/lib/types";

interface CropRecommendationsProps {
  selectedLand: SelectedLand;
}

export default function CropRecommendations({ selectedLand }: CropRecommendationsProps) {
  const { data: crops, isLoading } = useQuery({
    queryKey: ['/api/crops/recommended', selectedLand.region, selectedLand.soilType],
    staleTime: 1000 * 60 * 60, // 1 hour
  });

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden">
      <CardHeader className="border-b border-accent p-4">
        <CardTitle className="font-heading font-semibold text-xl text-primary">Recommended Crops</CardTitle>
        <p className="text-secondary text-sm">Based on your land selection, soil type, and current season</p>
      </CardHeader>
      <CardContent className="p-4">
        {isLoading ? (
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {crops?.map((crop, index) => (
                <div 
                  key={index}
                  className="crop-card bg-accent rounded-lg overflow-hidden shadow-sm hover:shadow-md transition duration-300"
                >
                  <img 
                    src={crop.imageUrl} 
                    alt={`${crop.name} crop`} 
                    className="w-full h-40 object-cover" 
                  />
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-heading font-semibold text-primary">{crop.name}</h4>
                      <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">{crop.matchPercentage}% match</span>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center text-secondary">
                        <i className="ri-water-flash-line mr-2"></i>
                        <span>Water needs: {crop.waterNeeds}</span>
                      </div>
                      <div className="flex items-center text-secondary">
                        <i className="ri-sun-line mr-2"></i>
                        <span>Growing period: {crop.growingPeriod}</span>
                      </div>
                      <div className="flex items-center text-secondary">
                        <i className="ri-seedling-line mr-2"></i>
                        <span>Best planting: {crop.bestPlanting}</span>
                      </div>
                    </div>
                    <Button 
                      className="mt-4 w-full bg-primary hover:bg-primary-dark text-white rounded-md py-2 transition"
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 text-center">
              <Button 
                variant="link" 
                className="text-primary hover:text-primary-dark font-medium flex items-center mx-auto"
              >
                <span>View more recommendations</span>
                <i className="ri-arrow-right-line ml-1"></i>
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

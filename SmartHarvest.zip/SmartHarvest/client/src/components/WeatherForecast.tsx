import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { fetchWeatherForecast } from "@/lib/api";

interface WeatherForecastProps {
  region: string;
}

export default function WeatherForecast({ region }: WeatherForecastProps) {
  const { data: forecast, isLoading } = useQuery({
    queryKey: ['/api/weather/forecast', region],
    staleTime: 1000 * 60 * 30, // 30 minutes
  });

  // Weather icon mapping
  const getWeatherIcon = (condition: string) => {
    const conditionLower = condition.toLowerCase();
    if (conditionLower.includes('sun') && conditionLower.includes('cloud')) {
      return "ri-sun-cloudy-line";
    } else if (conditionLower.includes('sun') || conditionLower.includes('clear')) {
      return "ri-sun-line";
    } else if (conditionLower.includes('cloud')) {
      return "ri-cloudy-line";
    } else if (conditionLower.includes('rain') || conditionLower.includes('drizzle')) {
      return "ri-drizzle-line";
    } else if (conditionLower.includes('thunder')) {
      return "ri-thunderstorms-line";
    } else {
      return "ri-sun-line"; // Default
    }
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden">
      <CardHeader className="border-b border-accent p-4">
        <CardTitle className="font-heading font-semibold text-xl text-primary">10-Day Weather Forecast</CardTitle>
        <p className="text-secondary text-sm">{region}</p>
      </CardHeader>
      <CardContent className="p-4">
        {isLoading ? (
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : (
          <>
            {forecast?.current && (
              <div className="bg-primary bg-opacity-10 p-4 rounded-lg mb-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-secondary">Today</p>
                    <p className="font-heading font-semibold text-primary-dark text-xl">
                      {forecast.current.temperature}°C
                    </p>
                    <p className="text-sm text-secondary">
                      Feels like {forecast.current.feelsLike}°C
                    </p>
                  </div>
                  <div className="text-center">
                    <i className={`${getWeatherIcon(forecast.current.condition)} text-4xl text-destructive`}></i>
                    <p className="text-sm text-secondary">{forecast.current.condition}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center justify-end text-sm text-secondary mb-1">
                      <i className="ri-drop-line mr-1"></i>
                      <span>{forecast.current.precipitation}% chance</span>
                    </div>
                    <div className="flex items-center justify-end text-sm text-secondary mb-1">
                      <i className="ri-water-percent-line mr-1"></i>
                      <span>{forecast.current.humidity}% humidity</span>
                    </div>
                    <div className="flex items-center justify-end text-sm text-secondary">
                      <i className="ri-windy-line mr-1"></i>
                      <span>{forecast.current.wind}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-3 custom-scrollbar max-h-96 overflow-y-auto pr-2">
              {forecast?.daily?.map((day, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-3 hover:bg-accent rounded-lg transition cursor-pointer"
                >
                  <div className="w-1/4">
                    <p className="font-medium text-primary">{day.date}</p>
                  </div>
                  <div className="w-1/4 text-center">
                    <i className={`${getWeatherIcon(day.condition)} text-2xl text-destructive`}></i>
                  </div>
                  <div className="w-1/4 text-center">
                    <p className="text-sm text-secondary">{day.precipitation}% rain</p>
                  </div>
                  <div className="w-1/4 text-right">
                    <p className="font-medium text-primary">{day.maxTemp}°C / {day.minTemp}°C</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 text-center">
              <Button 
                variant="link" 
                className="text-primary hover:text-primary-dark font-medium flex items-center mx-auto"
              >
                <span>View full forecast</span>
                <i className="ri-arrow-right-line ml-1"></i>
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

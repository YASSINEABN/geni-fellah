import { useState } from "react";
import { Link } from "wouter";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  
  const navLinks = [
    { label: "Dashboard", href: "/" },

  ];

  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <i className="ri-plant-line text-3xl text-accent"></i>
          <h1 className="font-heading font-bold text-2xl">جيني فلاح</h1>
        </div>
        
        <nav className="hidden md:flex items-center space-x-6">
          {navLinks.map((link, index) => (
            <Link 
              key={index} 
              href={link.href}
              className="font-heading font-medium hover:text-accent transition"
            >
              {link.label}
            </Link>
          ))}
        </nav>
        
        <div className="flex items-center space-x-3">
          <div className="hidden md:block">
            <span className="text-sm mr-2">مرحبا اسي لفلاح</span>
            <i className="ri-user-line"></i>
          </div>
          
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden text-white">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-primary text-white w-64">
              <div className="flex flex-col space-y-4 mt-8">
                {navLinks.map((link, index) => (
                  <Link 
                    key={index} 
                    href={link.href}
                    className="font-heading font-medium hover:text-accent transition py-2"
                    onClick={() => setIsOpen(false)}
                  >
                    {link.label}
                  </Link>
                ))}
                <div className="pt-4 border-t border-primary-foreground/20 mt-4">
                  <div className="flex items-center space-x-2">
                    <i className="ri-user-line"></i>
                    <span>مرحبا اسي لفلاح</span>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

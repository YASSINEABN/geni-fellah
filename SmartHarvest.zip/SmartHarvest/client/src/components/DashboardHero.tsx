import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchCurrentWeather } from "@/lib/api";

export default function DashboardHero() {
  const [currentDate, setCurrentDate] = useState("");
  
  useEffect(() => {
    const now = new Date();
    const options: Intl.DateTimeFormatOptions = { 
      month: 'long', 
      day: 'numeric', 
      year: 'numeric' 
    };
    setCurrentDate(now.toLocaleDateString('en-US', options));
  }, []);

  const { data: weather, isLoading } = useQuery({
    queryKey: ['/api/weather/current'],
    staleTime: 1000 * 60 * 15, // 15 minutes
  });

  return (
    <section className="mb-10">
      <div className="bg-gradient-to-r from-primary to-primary-light rounded-xl shadow-lg overflow-hidden">
        <div className="md:flex">
          <div className="p-8 md:w-2/3">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-white mb-4">
              لمرافق ديالك
            </h2>
            <p className="text-accent text-lg mb-6">
              Combining AI, geospatial technology, and real-time weather data to deliver intelligent insights for your farm.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                className="bg-white text-primary hover:bg-accent hover:text-primary-dark font-medium px-6 py-2 rounded-full shadow-md flex items-center"
              >
                <i className="ri-map-pin-line mr-2"></i> Select Land
              </Button>
              <Button 
                className="bg-secondary hover:bg-secondary-light text-white font-medium px-6 py-2 rounded-full shadow-md flex items-center"
              >
                <i className="ri-robot-line mr-2"></i> Ask Geni
              </Button>
            </div>
          </div>
          <div className="md:w-1/3 relative h-64 md:h-auto overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1625246333195-78d9c38ad449?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Modern agricultural field" 
              className="absolute inset-0 w-full h-full object-cover" 
            />
          </div>
        </div>
        <div className="bg-accent-foreground/20 px-8 py-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center text-white">
              <i className="ri-calendar-line mr-2"></i>
              <span>Today: {currentDate}</span>
            </div>
            
            {isLoading ? (
              <div className="flex items-center text-white">Loading weather data...</div>
            ) : (
              <>
                <div className="flex items-center text-white">
                  <i className="ri-sun-line mr-2"></i>
                  <span>{weather?.temperature}°C, {weather?.description}</span>
                </div>
                <div className="flex items-center text-white">
                  <i className="ri-water-percent-line mr-2"></i>
                  <span>Humidity: {weather?.humidity}%</span>
                </div>
                <div className="flex items-center text-white">
                  <i className="ri-drop-line mr-2"></i>
                  <span>Precipitation: {weather?.precipitation}%</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

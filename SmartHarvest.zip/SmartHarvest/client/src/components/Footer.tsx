import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-primary-dark text-white mt-16 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <i className="ri-plant-line text-2xl text-accent"></i>
              <h2 className="font-heading font-bold text-xl">Geni Fellah</h2>
            </div>
            <p className="text-accent text-sm">
              The smart agricultural assistant helping farmers make better decisions with AI and precision technology.
            </p>
          </div>
          <div>
            <h3 className="font-heading font-semibold mb-4">Features</h3>
            <ul className="space-y-2 text-accent text-sm">
              <li><Link href="#" className="hover:text-white transition">Smart Land Cropping</Link></li>
              <li><Link href="#" className="hover:text-white transition">AI Chatbot Assistant</Link></li>
              <li><Link href="#" className="hover:text-white transition">Weather Integration</Link></li>
              <li><Link href="#" className="hover:text-white transition">Irrigation Planning</Link></li>
              <li><Link href="#" className="hover:text-white transition">IoT Connectivity</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-heading font-semibold mb-4">Resources</h3>
            <ul className="space-y-2 text-accent text-sm">
              <li><Link href="#" className="hover:text-white transition">Crop Database</Link></li>
              <li><Link href="#" className="hover:text-white transition">Irrigation Guides</Link></li>
              <li><Link href="#" className="hover:text-white transition">Weather Forecasts</Link></li>
              <li><Link href="#" className="hover:text-white transition">Farming Techniques</Link></li>
              <li><Link href="#" className="hover:text-white transition">Local Agriculture Data</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-heading font-semibold mb-4">Contact</h3>
            <ul className="space-y-2 text-accent text-sm">
              <li className="flex items-center">
                <i className="ri-mail-line mr-2"></i>
                <a href="mailto:support@genifellah.com" className="hover:text-white transition">support@genifellah.com</a>
              </li>
              <li className="flex items-center">
                <i className="ri-phone-line mr-2"></i>
                <a href="tel:+212612345678" className="hover:text-white transition">+212 612 345 678</a>
              </li>
              <li className="flex items-center">
                <i className="ri-map-pin-line mr-2"></i>
                <span>Agadir, Morocco</span>
              </li>
            </ul>
            <div className="mt-4 flex space-x-3">
              <a href="#" className="text-accent hover:text-white transition"><i className="ri-facebook-fill text-lg"></i></a>
              <a href="#" className="text-accent hover:text-white transition"><i className="ri-twitter-fill text-lg"></i></a>
              <a href="#" className="text-accent hover:text-white transition"><i className="ri-instagram-fill text-lg"></i></a>
              <a href="#" className="text-accent hover:text-white transition"><i className="ri-youtube-fill text-lg"></i></a>
            </div>
          </div>
        </div>
        <div className="border-t border-primary mt-8 pt-6 text-center text-accent text-sm">
          <p>© {new Date().getFullYear()} Geni Fellah. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SelectedLand } from "@/lib/types";

// Import leaflet via CDN in index.html
declare global {
  interface Window {
    L: any;
  }
}

interface MapSelectorProps {
  selectedLand: SelectedLand;
  setSelectedLand: React.Dispatch<React.SetStateAction<SelectedLand>>;
}

export default function MapSelector({ selectedLand, setSelectedLand }: MapSelectorProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMapRef = useRef<any>(null);
  const drawnItemsRef = useRef<any>(null);

  useEffect(() => {
    if (!mapRef.current) return;
    
    // Add Leaflet CSS
    if (!document.querySelector('link[href*="leaflet.css"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(link);
    }
    
    // Add Leaflet Draw CSS
    if (!document.querySelector('link[href*="leaflet.draw.css"]')) {
      const drawLink = document.createElement('link');
      drawLink.rel = 'stylesheet';
      drawLink.href = 'https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css';
      document.head.appendChild(drawLink);
    }

    // Load Leaflet and Leaflet Draw scripts
    const loadScript = (src: string): Promise<void> => {
      return new Promise((resolve, reject) => {
        if (document.querySelector(`script[src="${src}"]`)) {
          resolve();
          return;
        }
        
        const script = document.createElement('script');
        script.src = src;
        script.onload = () => resolve();
        script.onerror = (e) => reject(e);
        document.body.appendChild(script);
      });
    };

    const initializeMap = async () => {
      try {
        await loadScript('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js');
        await loadScript('https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js');
        
        if (leafletMapRef.current) return;

        // Center coordinates for Souss-Massa region, Morocco
        const map = window.L.map(mapRef.current).setView([30.4202, -9.5981], 10);
        
        window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Add satellite layer
        window.L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
          attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
        }).addTo(map);

        // Initialize the FeatureGroup for the draw control
        const drawnItems = new window.L.FeatureGroup();
        map.addLayer(drawnItems);
        drawnItemsRef.current = drawnItems;

        // Initialize the draw control
        const drawControl = new window.L.Control.Draw({
          edit: {
            featureGroup: drawnItems,
            poly: {
              allowIntersection: false
            }
          },
          draw: {
            polygon: {
              allowIntersection: false,
              showArea: true
            },
            marker: false,
            circlemarker: false,
            polyline: false,
            circle: false,
            rectangle: {
              shapeOptions: {
                color: '#2D5A3D'
              }
            }
          }
        });
        
        map.addControl(drawControl);

        // Handle the created layer event
        map.on('draw:created', function(e: any) {
          drawnItems.clearLayers();
          drawnItems.addLayer(e.layer);
          
          // Calculate area in hectares (approximate)
          const area = window.L.GeometryUtil.geodesicArea(e.layer.getLatLngs()[0]);
          const areaInHectares = (area / 10000).toFixed(1);
          
          // Update land selection
          setSelectedLand(prev => ({
            ...prev,
            surfaceArea: `${areaInHectares} hectares`
          }));
        });

        // Handle the edited layer event
        map.on('draw:edited', function() {
          if (drawnItems.getLayers().length > 0) {
            const layer = drawnItems.getLayers()[0];
            const area = window.L.GeometryUtil.geodesicArea(layer.getLatLngs()[0]);
            const areaInHectares = (area / 10000).toFixed(1);
            
            setSelectedLand(prev => ({
              ...prev,
              surfaceArea: `${areaInHectares} hectares`
            }));
          }
        });

        // Handle the deleted layer event
        map.on('draw:deleted', function() {
          setSelectedLand(prev => ({
            ...prev,
            surfaceArea: "0 hectares"
          }));
        });

        leafletMapRef.current = map;
      } catch (error) {
        console.error("Error initializing map:", error);
      }
    };

    initializeMap();

    return () => {
      if (leafletMapRef.current) {
        leafletMapRef.current.remove();
        leafletMapRef.current = null;
      }
    };
  }, [setSelectedLand]);

  const handleClearMap = () => {
    if (drawnItemsRef.current) {
      drawnItemsRef.current.clearLayers();
      setSelectedLand(prev => ({
        ...prev,
        surfaceArea: "0 hectares"
      }));
    }
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden">
      <CardHeader className="border-b border-accent p-4 flex flex-row justify-between items-center space-y-0">
        <CardTitle className="font-heading font-semibold text-xl text-primary">Land Selection</CardTitle>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="bg-accent hover:bg-accent-foreground/20 text-secondary px-3 py-1 rounded-md text-sm flex items-center transition"
          >
            <i className="ri-pencil-line mr-1"></i> Draw
          </Button>
          <Button 
            variant="outline" 
            className="bg-accent hover:bg-accent-foreground/20 text-secondary px-3 py-1 rounded-md text-sm flex items-center transition"
          >
            <i className="ri-map-pin-line mr-1"></i> Select
          </Button>
          <Button 
            variant="outline" 
            onClick={handleClearMap}
            className="bg-accent hover:bg-accent-foreground/20 text-secondary px-3 py-1 rounded-md text-sm flex items-center transition"
          >
            <i className="ri-delete-bin-line mr-1"></i> Clear
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div 
          id="map" 
          ref={mapRef} 
          className="border-2 border-accent-foreground/20 h-96"
        ></div>
      </CardContent>
      <div className="bg-accent p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-3 rounded-lg shadow-sm">
            <p className="text-sm text-secondary">Region</p>
            <p className="font-semibold text-primary">{selectedLand.region}</p>
          </div>
          <div className="bg-white p-3 rounded-lg shadow-sm">
            <p className="text-sm text-secondary">Surface Area</p>
            <p className="font-semibold text-primary">{selectedLand.surfaceArea}</p>
          </div>
          <div className="bg-white p-3 rounded-lg shadow-sm">
            <p className="text-sm text-secondary">Soil Type</p>
            <p className="font-semibold text-primary">{selectedLand.soilType}</p>
          </div>
        </div>
      </div>
    </Card>
  );
}

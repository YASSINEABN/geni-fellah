import { useState, useEffect } from 'react';

interface TypingAnimationProps {
  message: string;
  typingSpeed?: number;
  onComplete?: () => void;
}

export default function TypingAnimation({
  message,
  typingSpeed = 20,
  onComplete
}: TypingAnimationProps) {
  const [displayedText, setDisplayedText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    if (currentIndex < message.length) {
      // Randomize typing speed a bit to make it more realistic
      const randomDelay = typingSpeed + Math.random() * (typingSpeed * 0.5);
      
      // Slightly longer pause for punctuation
      const currentChar = message[currentIndex];
      const extraDelay = ['.', ',', '!', '?', ';', ':'].includes(currentChar) ? 200 : 0;
      
      const timer = setTimeout(() => {
        setDisplayedText(message.substring(0, currentIndex + 1));
        setCurrentIndex(currentIndex + 1);
      }, randomDelay + extraDelay);
      
      return () => clearTimeout(timer);
    } else if (!isComplete) {
      setIsComplete(true);
      onComplete && onComplete();
    }
  }, [currentIndex, message, typingSpeed, isComplete, onComplete]);

  // Reset animation if message changes
  useEffect(() => {
    setDisplayedText('');
    setCurrentIndex(0);
    setIsComplete(false);
  }, [message]);

  return <div dangerouslySetInnerHTML={{ __html: displayedText.replace(/\n/g, '<br>') }} />;
}
import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { SelectedLand } from "@/lib/types";

interface Message {
  id: string;
  sender: "user" | "assistant";
  content: string;
}

interface AIChatbotProps {
  selectedLand: SelectedLand;
  selectedCrop: string;
}

export default function AIChatbot({ selectedLand, selectedCrop }: AIChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      sender: "assistant",
      content: "Hello! I'm Geni Fellah, your AI agricultural assistant. How can I help you today? You can ask about crops, irrigation, or farming techniques specific to your region."
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      sender: "user",
      content: input
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    
    try {
      const response = await apiRequest("POST", "/api/chat", {
        message: input,
        land: selectedLand,
        crop: selectedCrop
      });
      
      const responseData = await response.json();
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        content: responseData.response
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error sending message:", error);
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        content: "I'm sorry, I encountered an error processing your request. Please try again later."
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const suggestedQuestions = [
    "Best crops for my land?",
    "When to plant tomatoes?",
    "Common olive diseases?"
  ];

  const handleSuggestedQuestion = (question: string) => {
    setInput(question);
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden h-[calc(100vh-32rem)] min-h-[400px] flex flex-col">
      <CardHeader className="border-b border-accent p-4">
        <CardTitle className="font-heading font-semibold text-xl text-primary flex items-center">
          <i className="ri-robot-line mr-2 text-destructive"></i>
          Ask Geni Fellah
        </CardTitle>
        <p className="text-secondary text-sm">Your AI agricultural assistant</p>
      </CardHeader>
      <CardContent className="flex-grow p-4 overflow-y-auto custom-scrollbar" id="chat-messages">
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className="flex items-start">
              <div className={`${
                message.sender === "user" 
                  ? "bg-primary text-white rounded-lg p-3 ml-auto" 
                  : "bg-accent text-secondary rounded-lg p-3 mr-auto"
              } max-w-[80%]`}>
                <p dangerouslySetInnerHTML={{__html: message.content.replace(/\n/g, '<br>')}} />
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex items-start">
              <div className="bg-accent text-secondary rounded-lg p-3 mr-auto max-w-[80%]">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 rounded-full bg-secondary animate-bounce"></div>
                  <div className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                  <div className="w-2 h-2 rounded-full bg-secondary animate-bounce" style={{ animationDelay: "0.4s" }}></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </CardContent>
      <div className="p-4 border-t border-accent">
        <form className="flex gap-2" onSubmit={handleSendMessage}>
          <Input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about crops, irrigation, or farming techniques..." 
            className="flex-grow px-4 py-2 rounded-lg border border-accent focus:outline-none focus:border-primary transition"
            disabled={isLoading}
          />
          <Button 
            type="submit" 
            disabled={isLoading}
            className="bg-primary hover:bg-primary-dark text-white rounded-lg px-4 py-2 transition flex items-center"
          >
            <i className="ri-send-plane-fill"></i>
          </Button>
        </form>
        <div className="mt-2 flex flex-wrap gap-2">
          {suggestedQuestions.map((question, index) => (
            <Button
              key={index}
              type="button"
              variant="outline"
              onClick={() => handleSuggestedQuestion(question)}
              className="bg-accent text-secondary text-xs px-3 py-1 rounded-full hover:bg-accent-foreground/20 transition"
            >
              {question}
            </Button>
          ))}
        </div>
      </div>
    </Card>
  );
}

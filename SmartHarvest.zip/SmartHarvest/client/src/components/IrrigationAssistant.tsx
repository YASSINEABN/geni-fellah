import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { fetchIrrigationPlan } from "@/lib/api";
import { SelectedLand } from "@/lib/types";

interface IrrigationAssistantProps {
  selectedLand: SelectedLand;
  selectedCrop: string;
  setSelectedCrop: React.Dispatch<React.SetStateAction<string>>;
}

export default function IrrigationAssistant({ 
  selectedLand, 
  selectedCrop, 
  setSelectedCrop 
}: IrrigationAssistantProps) {
  const crops = ["Tomatoes", "Citrus", "Olives"];
  
  const { data: irrigationPlan, isLoading } = useQuery({
    queryKey: ['/api/irrigation/plan', selectedLand.region, selectedCrop, selectedLand.surfaceArea],
    staleTime: 1000 * 60 * 60, // 1 hour
  });

  const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden">
      <CardHeader className="border-b border-accent p-4">
        <CardTitle className="font-heading font-semibold text-xl text-primary">Irrigation Assistant</CardTitle>
        <p className="text-secondary text-sm">Optimized watering schedules for your selected crops</p>
      </CardHeader>
      <CardContent className="p-4">
        <div className="mb-6">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <span className="text-secondary mr-2">Selected crop:</span>
            {crops.map((crop, index) => (
              <Button
                key={index}
                variant={selectedCrop === crop ? "default" : "outline"}
                onClick={() => setSelectedCrop(crop)}
                className={
                  selectedCrop === crop 
                    ? "bg-accent text-primary px-3 py-1 rounded-full text-sm flex items-center hover:bg-accent-foreground/20 transition border border-accent-foreground/20" 
                    : "bg-white text-secondary px-3 py-1 rounded-full text-sm flex items-center hover:bg-accent transition border border-accent"
                }
              >
                <i className="ri-plant-line mr-1"></i> {crop}
              </Button>
            ))}
          </div>

          {isLoading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="bg-accent p-4 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-heading font-semibold text-primary">Recommended Irrigation Plan</h4>
                <span className="text-sm text-secondary">For {selectedLand.surfaceArea} of {selectedCrop.toLowerCase()}</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="bg-white p-3 rounded-lg shadow-sm">
                  <p className="text-sm text-secondary">Irrigation Method</p>
                  <div className="flex items-center">
                    <img 
                      src="https://pixabay.com/get/g6ffe69eddb10e216537fdc00b0fa92496293a724f83d50513292a381b233bea1a2171b7c82f527e478c14823fee7933537d700f1aa09f359332483fe716bb25c_1280.jpg" 
                      alt="Drip irrigation" 
                      className="h-10 w-10 rounded-full object-cover mr-2" 
                    />
                    <p className="font-semibold text-primary">{irrigationPlan?.method}</p>
                  </div>
                </div>
                <div className="bg-white p-3 rounded-lg shadow-sm">
                  <p className="text-sm text-secondary">Water Requirement</p>
                  <p className="font-semibold text-primary">{irrigationPlan?.waterRequirement}</p>
                </div>
                <div className="bg-white p-3 rounded-lg shadow-sm">
                  <p className="text-sm text-secondary">Watering Schedule</p>
                  <p className="font-semibold text-primary">{irrigationPlan?.schedule}</p>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h5 className="font-heading font-medium text-primary mb-2">Weekly Watering Schedule</h5>
                <div className="grid grid-cols-7 gap-2">
                  {weekDays.map((day, index) => (
                    <div key={index} className="text-center py-2">
                      <p className="text-xs text-secondary">{day}</p>
                      <div 
                        className={`mt-1 mx-auto h-8 w-8 rounded-full ${
                          irrigationPlan?.weeklySchedule.includes(day) 
                            ? "bg-primary-light flex items-center justify-center" 
                            : "bg-accent flex items-center justify-center"
                        }`}
                      >
                        {irrigationPlan?.weeklySchedule.includes(day) ? (
                          <i className="ri-water-flash-fill text-white"></i>
                        ) : (
                          <i className="ri-close-line text-secondary"></i>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

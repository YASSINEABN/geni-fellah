import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SelectedLand } from "@/lib/types";

// Import leaflet via CDN in index.html
declare global {
  interface Window {
    L: any;
  }
}

interface SimpleMapSelectorProps {
  selectedLand: SelectedLand;
  setSelectedLand: React.Dispatch<React.SetStateAction<SelectedLand>>;
  onMapSelection: () => void;
}

export default function SimpleMapSelector({ 
  selectedLand, 
  setSelectedLand,
  onMapSelection
}: SimpleMapSelectorProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMapRef = useRef<any>(null);
  const drawnItemsRef = useRef<any>(null);

  useEffect(() => {
    if (!mapRef.current) return;
    
    // Add Leaflet CSS
    if (!document.querySelector('link[href*="leaflet.css"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(link);
    }
    
    // Add Leaflet Draw CSS
    if (!document.querySelector('link[href*="leaflet.draw.css"]')) {
      const drawLink = document.createElement('link');
      drawLink.rel = 'stylesheet';
      drawLink.href = 'https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css';
      document.head.appendChild(drawLink);
    }

    // Load Leaflet and Leaflet Draw scripts
    const loadScript = (src: string): Promise<void> => {
      return new Promise((resolve, reject) => {
        if (document.querySelector(`script[src="${src}"]`)) {
          resolve();
          return;
        }
        
        const script = document.createElement('script');
        script.src = src;
        script.onload = () => resolve();
        script.onerror = (e) => reject(e);
        document.body.appendChild(script);
      });
    };

    const initializeMap = async () => {
      try {
        await loadScript('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js');
        await loadScript('https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js');
        
        if (leafletMapRef.current) return;

        // Center coordinates for Morocco
        const map = window.L.map(mapRef.current).setView([31.7917, -7.0926], 6);
        
        window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Add satellite layer option
        const baseMaps = {
          "Street": window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          }),
          "Satellite": window.L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
          })
        };
        
        window.L.control.layers(baseMaps).addTo(map);

        // Initialize the FeatureGroup for the draw control
        const drawnItems = new window.L.FeatureGroup();
        map.addLayer(drawnItems);
        drawnItemsRef.current = drawnItems;

        // Define regions with approximate coordinates
        const regions = {
          'Souss-Massa': {
            center: [30.4, -9.0],
            name: 'Souss-Massa, Morocco',
            soilType: 'Loamy with good drainage'
          },
          'Marrakech-Safi': {
            center: [31.6, -8.0],
            name: 'Marrakech-Safi, Morocco',
            soilType: 'Clay-loam, moderately fertile'
          },
          'Tangier-Tétouan': {
            center: [35.7, -5.9],
            name: 'Tangier-Tétouan-Al Hoceima, Morocco',
            soilType: 'Sandy loam with variable drainage'
          }
        };
        
        // Add approximate region boundaries
        Object.entries(regions).forEach(([key, region]) => {
          const circle = window.L.circle(region.center, {
            color: '#2D5A3D',
            fillColor: '#2D5A3D',
            fillOpacity: 0.2,
            radius: 50000
          });
          
          circle.addTo(map);
          circle.bindTooltip(region.name);
        });

        // Initialize the draw control
        const drawControl = new window.L.Control.Draw({
          edit: {
            featureGroup: drawnItems,
            poly: {
              allowIntersection: false
            }
          },
          draw: {
            polygon: {
              allowIntersection: false,
              showArea: true,
              shapeOptions: {
                color: '#2D5A3D'
              }
            },
            marker: false,
            circlemarker: false,
            polyline: false,
            circle: false,
            rectangle: {
              shapeOptions: {
                color: '#2D5A3D'
              }
            }
          }
        });
        
        map.addControl(drawControl);

        // Handle the created layer event
        map.on('draw:created', function(e: any) {
          drawnItems.clearLayers();
          drawnItems.addLayer(e.layer);
          
          // Calculate area in hectares (approximate)
          let area = 0;
          if (e.layerType === 'polygon') {
            area = window.L.GeometryUtil.geodesicArea(e.layer.getLatLngs()[0]);
          } else if (e.layerType === 'rectangle') {
            area = window.L.GeometryUtil.geodesicArea(e.layer.getLatLngs()[0]);
          }
          const areaInHectares = (area / 10000).toFixed(1);
          
          // Determine region based on the center of the drawn shape
          let layerCenter;
          if (e.layerType === 'polygon') {
            layerCenter = e.layer.getBounds().getCenter();
          } else {
            layerCenter = e.layer.getBounds().getCenter();
          }
          
          // Find the closest region
          let closestRegion = 'Souss-Massa';
          let minDistance = Infinity;
          
          Object.entries(regions).forEach(([key, region]) => {
            const distance = layerCenter.distanceTo(window.L.latLng(region.center[0], region.center[1]));
            if (distance < minDistance) {
              minDistance = distance;
              closestRegion = key;
            }
          });
          
          const regionInfo = regions[closestRegion as keyof typeof regions];
          
          // Update land selection
          setSelectedLand({
            region: regionInfo.name,
            surfaceArea: `${areaInHectares} hectares`,
            soilType: regionInfo.soilType
          });
        });

        // Handle the edited layer event
        map.on('draw:edited', function() {
          if (drawnItems.getLayers().length > 0) {
            const layer = drawnItems.getLayers()[0];
            let area = 0;
            
            if (layer.getLatLngs) {
              area = window.L.GeometryUtil.geodesicArea(layer.getLatLngs()[0]);
            } else {
              area = window.L.GeometryUtil.geodesicArea(layer.getBounds());
            }
            
            const areaInHectares = (area / 10000).toFixed(1);
            
            setSelectedLand(prev => ({
              ...prev,
              surfaceArea: `${areaInHectares} hectares`
            }));
          }
        });

        // Handle the deleted layer event
        map.on('draw:deleted', function() {
          setSelectedLand(prev => ({
            ...prev,
            surfaceArea: "0 hectares"
          }));
        });

        leafletMapRef.current = map;
      } catch (error) {
        console.error("Error initializing map:", error);
      }
    };

    initializeMap();

    return () => {
      if (leafletMapRef.current) {
        leafletMapRef.current.remove();
        leafletMapRef.current = null;
      }
    };
  }, [setSelectedLand]);

  const handleClearMap = () => {
    if (drawnItemsRef.current) {
      drawnItemsRef.current.clearLayers();
      setSelectedLand(prev => ({
        ...prev,
        surfaceArea: "0 hectares"
      }));
    }
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden">
      <CardHeader className="border-b border-accent p-4 flex flex-row justify-between items-center space-y-0">
        <CardTitle className="font-heading font-semibold text-xl text-primary">Draw Your Land</CardTitle>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="bg-accent hover:bg-accent-foreground/20 text-secondary px-3 py-1 rounded-md text-sm flex items-center transition"
          >
            <i className="ri-pencil-line mr-1"></i> Draw
          </Button>
          <Button 
            variant="outline" 
            onClick={handleClearMap}
            className="bg-accent hover:bg-accent-foreground/20 text-secondary px-3 py-1 rounded-md text-sm flex items-center transition"
          >
            <i className="ri-delete-bin-line mr-1"></i> Clear
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div 
          id="map" 
          ref={mapRef} 
          className="border-2 border-accent-foreground/20 h-96"
        ></div>
      </CardContent>
      <div className="bg-accent p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-3 rounded-lg shadow-sm">
            <p className="text-sm text-secondary">Region</p>
            <p className="font-semibold text-primary">{selectedLand.region}</p>
          </div>
          <div className="bg-white p-3 rounded-lg shadow-sm">
            <p className="text-sm text-secondary">Surface Area</p>
            <p className="font-semibold text-primary">{selectedLand.surfaceArea}</p>
          </div>
          <div className="bg-white p-3 rounded-lg shadow-sm">
            <p className="text-sm text-secondary">Soil Type</p>
            <p className="font-semibold text-primary">{selectedLand.soilType}</p>
          </div>
        </div>
        
        <div className="mt-4 flex justify-center">
          <Button 
            onClick={onMapSelection}
            className="bg-primary hover:bg-primary-dark text-white font-medium px-6 py-2 rounded-full shadow-md flex items-center"
            disabled={selectedLand.surfaceArea === "0 hectares"}
          >
            <i className="ri-robot-line mr-2"></i>
            Consult Your Expert
          </Button>
        </div>
        {selectedLand.surfaceArea === "0 hectares" && (
          <div className="text-center mt-2 text-secondary text-sm">
            <i className="ri-information-line mr-1"></i>
            Draw your land on the map to enable expert consultation
          </div>
        )}
      </div>
    </Card>
  );
}
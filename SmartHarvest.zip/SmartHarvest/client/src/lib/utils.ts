import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date): string {
  const options: Intl.DateTimeFormatOptions = { 
    weekday: 'short',
    month: 'short', 
    day: 'numeric'
  };
  return date.toLocaleDateString('en-US', options);
}

export function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export function calculateDaysBetween(startDate: Date, endDate: Date): number {
  const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
  return Math.round(Math.abs((startDate.getTime() - endDate.getTime()) / oneDay));
}

export function getWeatherIcon(condition: string): string {
  const conditionLower = condition.toLowerCase();
  if (conditionLower.includes('sun') && conditionLower.includes('cloud')) {
    return "ri-sun-cloudy-line";
  } else if (conditionLower.includes('sun') || conditionLower.includes('clear')) {
    return "ri-sun-line";
  } else if (conditionLower.includes('cloud')) {
    return "ri-cloudy-line";
  } else if (conditionLower.includes('rain') || conditionLower.includes('drizzle')) {
    return "ri-drizzle-line";
  } else if (conditionLower.includes('thunder')) {
    return "ri-thunderstorms-line";
  } else {
    return "ri-sun-line"; // Default
  }
}

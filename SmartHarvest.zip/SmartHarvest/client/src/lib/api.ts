import { 
  Crop, 
  WeatherForecast, 
  IrrigationPlan 
} from "./types";

// Fetch current weather data
export async function fetchCurrentWeather() {
  const response = await fetch('/api/weather/current');
  if (!response.ok) {
    throw new Error('Failed to fetch current weather data');
  }
  return response.json();
}

// Fetch weather forecast
export async function fetchWeatherForecast(region: string): Promise<WeatherForecast> {
  const response = await fetch(`/api/weather/forecast?region=${encodeURIComponent(region)}`);
  if (!response.ok) {
    throw new Error('Failed to fetch weather forecast');
  }
  return response.json();
}

// Fetch recommended crops
export async function fetchRecommendedCrops(region: string, soilType: string): Promise<Crop[]> {
  const response = await fetch(`/api/crops/recommended?region=${encodeURIComponent(region)}&soilType=${encodeURIComponent(soilType)}`);
  if (!response.ok) {
    throw new Error('Failed to fetch recommended crops');
  }
  return response.json();
}

// Fetch irrigation plan
export async function fetchIrrigationPlan(
  region: string,
  crop: string,
  surfaceArea: string
): Promise<IrrigationPlan> {
  const response = await fetch(
    `/api/irrigation/plan?region=${encodeURIComponent(region)}&crop=${encodeURIComponent(crop)}&surfaceArea=${encodeURIComponent(surfaceArea)}`
  );
  if (!response.ok) {
    throw new Error('Failed to fetch irrigation plan');
  }
  return response.json();
}

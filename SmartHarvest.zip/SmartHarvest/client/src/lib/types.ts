// Land Selection Types
export interface SelectedLand {
  region: string;
  surfaceArea: string;
  soilType: string;
}

// Crop Types
export interface Crop {
  id: number;
  name: string;
  imageUrl: string;
  matchPercentage: number;
  waterNeeds: string;
  growingPeriod: string;
  bestPlanting: string;
  description?: string;
}

// Weather Types
export interface CurrentWeather {
  temperature: number;
  description: string;
  feelsLike: number;
  humidity: number;
  precipitation: number;
  wind: string;
  condition: string;
}

export interface DailyForecast {
  date: string;
  condition: string;
  maxTemp: number;
  minTemp: number;
  precipitation: number;
}

export interface WeatherForecast {
  current: CurrentWeather;
  daily: DailyForecast[];
}

// Irrigation Types
export interface IrrigationPlan {
  method: string;
  waterRequirement: string;
  schedule: string;
  weeklySchedule: string[];
}

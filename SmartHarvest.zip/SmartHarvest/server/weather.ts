import { format, addDays } from "date-fns";

// Interface for current weather data
interface CurrentWeather {
  temperature: number;
  description: string;
  feelsLike: number;
  humidity: number;
  precipitation: number;
  wind: string;
  condition: string;
}

// Interface for daily forecast
interface DailyForecast {
  date: string;
  condition: string;
  maxTemp: number;
  minTemp: number;
  precipitation: number;
}

// Interface for weather forecast
interface WeatherForecast {
  current: CurrentWeather;
  daily: DailyForecast[];
}

// Get current weather data
export async function getWeatherData(region: string): Promise<CurrentWeather> {
  // In a production app, this would call OpenWeatherMap API
  // For now, return realistic sample data for the region
  
  const currentDate = new Date();
  const hour = currentDate.getHours();
  
  // Simulate different weather based on time of day
  let temperature, description, condition;
  
  if (hour >= 5 && hour < 10) {
    // Morning
    temperature = 22 + Math.floor(Math.random() * 3);
    description = "Partly Cloudy";
    condition = "Partly Cloudy";
  } else if (hour >= 10 && hour < 16) {
    // Midday
    temperature = 28 + Math.floor(Math.random() * 3);
    description = "Sunny";
    condition = "Sunny";
  } else if (hour >= 16 && hour < 20) {
    // Evening
    temperature = 25 + Math.floor(Math.random() * 3);
    description = "Clear";
    condition = "Clear";
  } else {
    // Night
    temperature = 18 + Math.floor(Math.random() * 3);
    description = "Clear";
    condition = "Clear";
  }
  
  // Calculate feels like temperature (slightly higher than actual in dry climate)
  const feelsLike = temperature + Math.floor(Math.random() * 3);
  
  // Generate random but realistic humidity for Morocco
  const humidity = 35 + Math.floor(Math.random() * 20);
  
  // Generate precipitation chance (usually low in Souss-Massa)
  const precipitation = Math.floor(Math.random() * 10);
  
  // Generate wind data
  const windSpeed = 5 + Math.floor(Math.random() * 10);
  const windDirections = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  const windDirection = windDirections[Math.floor(Math.random() * windDirections.length)];
  const wind = `${windSpeed} km/h ${windDirection}`;
  
  return {
    temperature,
    description,
    feelsLike,
    humidity,
    precipitation,
    wind,
    condition
  };
}

// Get weather forecast
export async function getWeatherForecast(region: string): Promise<WeatherForecast> {
  // Get current weather
  const current = await getWeatherData(region);
  
  // Generate 10-day forecast
  const daily: DailyForecast[] = [];
  const currentDate = new Date();
  
  // Weather conditions for variety
  const conditions = [
    "Sunny", 
    "Partly Cloudy", 
    "Cloudy", 
    "Drizzle", 
    "Sunny"
  ];
  
  // Generate next 10 days
  for (let i = 1; i <= 10; i++) {
    const forecastDate = addDays(currentDate, i);
    
    // Format date as "Tue, Apr 25"
    const formattedDate = format(forecastDate, "E, MMM d");
    
    // Randomize weather conditions with bias toward sunny/clear in Morocco
    const conditionIndex = Math.floor(Math.random() * conditions.length);
    const condition = conditions[conditionIndex];
    
    // Generate temperatures with some day-to-day variation
    // but maintaining a realistic pattern
    const baseMaxTemp = 26 + Math.floor(Math.random() * 5);
    const baseMinTemp = baseMaxTemp - 10 - Math.floor(Math.random() * 3);
    
    // Higher precipitation chance for cloudy/rainy conditions
    let precipitation = 5; // Default
    if (condition === "Partly Cloudy") {
      precipitation = 10 + Math.floor(Math.random() * 10);
    } else if (condition === "Cloudy") {
      precipitation = 20 + Math.floor(Math.random() * 20);
    } else if (condition === "Drizzle") {
      precipitation = 40 + Math.floor(Math.random() * 20);
    }
    
    daily.push({
      date: formattedDate,
      condition,
      maxTemp: baseMaxTemp,
      minTemp: baseMinTemp,
      precipitation
    });
  }
  
  return {
    current,
    daily
  };
}

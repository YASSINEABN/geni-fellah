import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getWeatherData, getWeatherForecast } from "./weather";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.get('/api/weather/current', getCurrentWeather);
  app.get('/api/weather/forecast', getWeatherForecastData);
  app.get('/api/crops/recommended', getRecommendedCrops);
  app.get('/api/irrigation/plan', getIrrigationPlan);
  app.post('/api/chat', handleChatMessage);

  const httpServer = createServer(app);
  return httpServer;
}

// Get current weather
async function getCurrentWeather(req: Request, res: Response) {
  try {
    const currentWeather = await getWeatherData("Souss-Massa, Morocco");
    res.json(currentWeather);
  } catch (error) {
    console.error("Error fetching current weather:", error);
    res.status(500).json({ message: "Failed to fetch current weather data" });
  }
}

// Get weather forecast
async function getWeatherForecastData(req: Request, res: Response) {
  try {
    const { region } = req.query;
    const forecast = await getWeatherForecast(region as string || "Souss-Massa, Morocco");
    res.json(forecast);
  } catch (error) {
    console.error("Error fetching weather forecast:", error);
    res.status(500).json({ message: "Failed to fetch weather forecast" });
  }
}

// Get recommended crops
async function getRecommendedCrops(req: Request, res: Response) {
  try {
    const { region, soilType } = req.query;
    const crops = await storage.getRecommendedCrops(
      region as string || "Souss-Massa, Morocco", 
      soilType as string || "Loamy with good drainage"
    );
    res.json(crops);
  } catch (error) {
    console.error("Error fetching recommended crops:", error);
    res.status(500).json({ message: "Failed to fetch recommended crops" });
  }
}

// Get irrigation plan
async function getIrrigationPlan(req: Request, res: Response) {
  try {
    const { region, crop, surfaceArea } = req.query;
    const irrigationPlan = await storage.getIrrigationPlan(
      region as string || "Souss-Massa, Morocco",
      crop as string || "Tomatoes",
      surfaceArea as string || "5.2 hectares"
    );
    res.json(irrigationPlan);
  } catch (error) {
    console.error("Error fetching irrigation plan:", error);
    res.status(500).json({ message: "Failed to fetch irrigation plan" });
  }
}

// Handle chat message
async function handleChatMessage(req: Request, res: Response) {
  try {
    const { message, land, crop } = req.body;
    
    if (!message) {
      return res.status(400).json({ message: "Message is required" });
    }
    
    const response = await storage.processChatMessage(message, land, crop);
    res.json({ response });
  } catch (error) {
    console.error("Error processing chat message:", error);
    res.status(500).json({ message: "Failed to process chat message" });
  }
}

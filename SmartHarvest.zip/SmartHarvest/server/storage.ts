import { 
  users, 
  type User, 
  type InsertUser,
  type Crop,
  type WeatherData,
  type ChatMessage
} from "@shared/schema";

// Import types from client-side
interface SelectedLand {
  region: string;
  surfaceArea: string;
  soilType: string;
}

interface IrrigationPlan {
  method: string;
  waterRequirement: string;
  schedule: string;
  weeklySchedule: string[];
}

// Extend the storage interface
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getRecommendedCrops(region: string, soilType: string): Promise<Crop[]>;
  getIrrigationPlan(region: string, crop: string, surfaceArea: string): Promise<IrrigationPlan>;
  processChatMessage(message: string, land: SelectedLand, crop: string): Promise<string>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private crops: Map<number, Crop>;
  private weatherData: Map<string, WeatherData[]>;
  private chatMessages: Map<number, ChatMessage>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.crops = new Map();
    this.weatherData = new Map();
    this.chatMessages = new Map();
    this.currentId = 1;
    
    // Initialize with sample crop data
    this.initializeCrops();
  }

  private initializeCrops() {
    const sampleCrops: Crop[] = [
      {
        id: 1,
        name: "Tomatoes",
        imageUrl: "https://images.unsplash.com/photo-1592841200221-a6898f307baa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250",
        waterNeeds: "Medium",
        growingPeriod: "90-120 days",
        bestPlanting: "March-April",
        description: "Tomatoes thrive in the warm climate of Souss-Massa. They require regular watering and full sun exposure."
      },
      {
        id: 2,
        name: "Citrus",
        imageUrl: "https://pixabay.com/get/g8ac615160ec000a77ad8ad51072b7213e4e1b06f313f64110433b19a90ed6a093085ed169ae927c68deef6a964b4a210b29e9e9e4cb0635efb5d0db3ee60feaa_1280.jpg",
        waterNeeds: "Medium-High",
        growingPeriod: "3-5 years",
        bestPlanting: "Spring",
        description: "Citrus trees are well-adapted to the Mediterranean climate. They need good drainage and protection from strong winds."
      },
      {
        id: 3,
        name: "Olives",
        imageUrl: "https://images.unsplash.com/photo-1595841696677-6489ff3f8cd1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250",
        waterNeeds: "Low",
        growingPeriod: "3-4 years",
        bestPlanting: "Spring/Fall",
        description: "Olives are drought-resistant and well-suited for the Moroccan climate. They prefer well-drained soil and full sun exposure."
      }
    ];
    
    sampleCrops.forEach(crop => {
      this.crops.set(crop.id, crop);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getRecommendedCrops(region: string, soilType: string): Promise<Crop[]> {
    // In a real app, this would filter based on region and soil type
    // For now, return all crops with added match percentage
    const crops = Array.from(this.crops.values());
    
    return crops.map(crop => {
      let matchPercentage = 0;
      
      // Simple matching logic based on crop and region
      if (crop.name === "Tomatoes" && region.includes("Souss-Massa")) {
        matchPercentage = 95;
      } else if (crop.name === "Citrus" && region.includes("Souss-Massa")) {
        matchPercentage = 93;
      } else if (crop.name === "Olives" && region.includes("Souss-Massa")) {
        matchPercentage = 88;
      } else {
        // Default match percentage
        matchPercentage = 70 + Math.floor(Math.random() * 20);
      }
      
      return {
        ...crop,
        matchPercentage
      };
    });
  }

  async getIrrigationPlan(region: string, crop: string, surfaceArea: string): Promise<IrrigationPlan> {
    // Calculate irrigation plan based on crop, region and surface area
    let method = "Drip Irrigation";
    let waterRequirement = "4,500 m³ per season";
    let schedule = "Every 3 days (early morning)";
    let weeklySchedule = ["Mon", "Thu", "Sun"];
    
    // Adjust based on crop
    if (crop === "Citrus") {
      waterRequirement = "6,000 m³ per season";
      schedule = "Every 4 days (morning)";
      weeklySchedule = ["Mon", "Fri"];
    } else if (crop === "Olives") {
      waterRequirement = "3,000 m³ per season";
      schedule = "Every 5 days (morning)";
      weeklySchedule = ["Mon", "Sat"];
    }
    
    // Adjust based on surface area
    if (surfaceArea) {
      const areaMatch = surfaceArea.match(/(\d+\.?\d*)/);
      if (areaMatch && areaMatch[1]) {
        const area = parseFloat(areaMatch[1]);
        if (!isNaN(area)) {
          // Simple scaling based on area
          const baseCropArea = 5.2; // base calculation was for 5.2 hectares
          const ratio = area / baseCropArea;
          
          // Extract base water volume
          const waterMatch = waterRequirement.match(/(\d+,\d+)/);
          if (waterMatch && waterMatch[1]) {
            const baseVolume = parseInt(waterMatch[1].replace(',', ''));
            const newVolume = Math.round(baseVolume * ratio);
            waterRequirement = `${newVolume.toLocaleString()} m³ per season`;
          }
        }
      }
    }
    
    return {
      method,
      waterRequirement,
      schedule,
      weeklySchedule
    };
  }

  async processChatMessage(message: string, land: SelectedLand, crop: string): Promise<string> {
    // Responses in Arabic Darija only
    
    const messageLower = message.toLowerCase();
    
    if (messageLower.includes("irrigation") || messageLower.includes("water") || messageLower.includes("sqi") || 
        messageLower.includes("سقي") || messageLower.includes("ري") || messageLower.includes("ماء")) {
      return `بالنسبة لـ ${crop} في منطقة ${land.region} بتربة ${land.soilType}، كننصحك بـ "الري بالتقطير". هاد الطريقة مهمة باش توفر الماء وتوصل الماء مباشرة للجذور ديال النبتة.

مع ${land.surfaceArea} ديال الأرض، غادي تحتاج تقريباً 4,500 متر مكعب ديال الماء كل موسم. أفضل جدول ديال السقي هو كل 3 أيام فالصباح المبكر باش ما يتبخرش الماء.`;
    }
    
    if (messageLower.includes("disease") || messageLower.includes("pest") || messageLower.includes("mard") || messageLower.includes("hshorat") ||
        messageLower.includes("مرض") || messageLower.includes("آفة") || messageLower.includes("حشرات")) {
      if (crop === "Tomatoes") {
        return `الأمراض الشائعة ديال الطماطم في منطقتك كاين "اللفحة المبكرة"، "اللفحة المتأخرة"، و"الذبول الفيوزاريومي". باش تحمي منهم:

1. ختار أنواع مقاومة للمرض
2. دير دورات زراعية
3. تأكد من مسافة مزيانة بين النباتات باش يمشي الهواء بينهم
4. سقي في الجذور باش الأوراق يبقاو ناشفين
5. ستعمل مبيدات فطرية عضوية قبل ما يجيك المرض

الحشرات اللي غالباً كيكونو هوما "الذبابة البيضاء" و"دودة القرن". فكر تستعمل صابون ديال الحشرات ولا زيد حشرات نافعة باش تقاومهم.`;
      } else if (crop === "Citrus") {
        return `الأمراض اللي كيصيبو الليمون في منطقتك كاين "التخضير ديال الليمون"، "تقرّح الليمون"، و"عفن الجذور". باش تحميهم:

1. شري شتلات مصادق عليها خالية من المرض
2. تأكد من تصريف الماء مزيان
3. ستعمل مبيدات فطرية بالنحاس قبل ما يجيك المرض
4. قصّ الفروع المريضة فوراً

للحشرات بحال "المن" و"ناقبات أوراق الحمضيات"، فكر في زيادة "بوزروڭ" واستعمال زيت الأزادراختين.`;
      } else if (crop === "Olives") {
        return `الأمراض اللي كيصيبو الزيتون كاين "عقد الزيتون"، "بقعة الطاووس"، و"ذبول الفرتيسيليوم". باش تحميهم:

1. قص مزيان باش يهوّى بين الفروع
2. دير دوايات بالنحاس قبل موسم الشتا
3. تجنب التسميد الزائد ديال النيتروجين

ذبابة ثمار الزيتون هي الأكثر ضرراً. استعمل مصايد الفيرومون اللي ماغادي يقتلوهمش ولكين غادي يعطيوك فكرة على عددهم، واستعمل دوايات عضوية منين يتحتاج الأمر.`;
      }
    }
    
    if (messageLower.includes("fertilizer") || messageLower.includes("nutrient") || messageLower.includes("smmad") || messageLower.includes("mghdi") ||
        messageLower.includes("سماد") || messageLower.includes("مغذي") || messageLower.includes("تسميد")) {
      if (crop === "Tomatoes") {
        return `للطماطم في هاد النوع ديال التربة (${land.soilType})، كنصحك بـ:

1. قبل ما تزرع: دير كومبوست وسماد متوازن (10-10-10)
2. في وقت الإزهار: بدل لسماد عالي في الفوسفور والبوتاسيوم (5-10-10)
3. زيد الكالسيوم باش تحمي من عفن طرف النوارات

فكر في تحليل ديال التربة باش تعرف بدقة أش كيصلح للأرض ديالك.`;
      } else if (crop === "Citrus") {
        return `شجر الليمون كيحتاجو لسماد خاص بالليمون بنسبة NPK تقريباً 2-1-1. دير سماد تلات مرات في العام (فبراير، ماي، وشتنبر) للشجر الكبار. لهاد النوع ديال التربة، تأكد من مستوى مزيان ديال المغنيسيوم، حيت شجر الليمون غالباً ما عندهمش بزاف منو.`;
      } else if (crop === "Olives") {
        return `الزيتون بشكل عام كيحتاج سماد أقل من باقي شجر الفاكهة. دير سماد متوازن (بحال 16-16-16) في الربيع المبكر. الزيتون كيستافد بزاف من البوتاسيوم، فكر في زيادة ديال سلفات البوتاسيوم في عام بعد عام. تجنب التسميد الزائد بالنيتروجين حيت كينقص الإنتاج ديال الفاكهة.`;
      }
    }
    
    if (messageLower.includes("plant") || messageLower.includes("grow") || messageLower.includes("zra3") || messageLower.includes("ghrs") ||
        messageLower.includes("زرع") || messageLower.includes("غرس") || messageLower.includes("نبت") || messageLower.includes("نزرع")) {
      if (crop === "Tomatoes") {
        return `باش تزرع طماطم في ${land.region}:

1. أفضل وقت الغرس: مارس-أبريل بعد ما تصالي الصقيعة
2. المسافة: 45-60 سنتيمتر بين النبتات، 90-120 سنتيمتر بين الصفوف
3. غرسها غميقة باش تجذّر مزيان
4. استعمل عواد ولا أقفاص باش تعاونها توقف
5. دير مولش باش تحبس الماء وتنقص الأعشاب الضارة

الطماطم كتبغي شمس كاملة وسقي منتظم. لهاد التربة ديالك، زيد مواد عضوية قبل الغرس باش تحسن الخصوبة وتصريف الماء.`;
      } else if (crop === "Citrus") {
        return `باش تزرع الليمون في ${land.region}:

1. أفضل وقت الغرس: الربيع (مارس-ماي)
2. المسافة: 4-6 متر بين الشجر
3. حفر حفرة مرتين عرض كورة الجذور ولكن ماشي عميقة
4. سقي مزيان بعد الغرس
5. دير مولش حدا (ولكن ما يمسش) الجذع

شجر الليمون الصغار كيحتاجو الحماية من الريح القوي والصقيعة. فكر تدير حاجز الريح وحماية الصقيعة في السنين الأولى.`;
      } else if (crop === "Olives") {
        return `باش تزرع الزيتون في ${land.region}:

1. أفضل وقت الغرس: ربيع المتأخر ولا الخريف
2. المسافة: 5-8 متر بين الشجر
3. ختار بلاصة مشمشة بتربة مزيانة التصريف
4. حفر حفرة بضعف قياس كورة الجذور
5. سقي عميق ولكن ماشي بزاف باش تجذر

الزيتون كيقدر الجفاف منين كيتكبر ولكين كيحتاج سقي منتظم في 2-3 سنين الأولى. معظم الأنواع كيحتاجو نوع آخر ديال الزيتون قريب منهم باش يجي اللقاح.`;
      }
    }
    
    if (messageLower.includes("climate") || messageLower.includes("weather") || messageLower.includes("mnakh") || messageLower.includes("tqs") ||
        messageLower.includes("مناخ") || messageLower.includes("طقس") || messageLower.includes("جو")) {
      return `منطقة ${land.region} عندها مناخ متوسطي بصيف سخون وناشف، وشتا معتدل ورطب. هاد المناخ مثالي لزراعة ${crop} إلا كانت عندك تدبيرات سقي مناسبة.

معدل تساقطات الأمطار سنوي بين 300-500مم، غالباً في شهور الشتا. درجات الحرارة في الصيف عادة بين 25-35 درجة، بينما في الشتا نادراً ما كتنزل لتحت من 5 درجات.

لزراعة ${crop}، انتبه لموجات الحر اللي كيجيو مرات في يوليوز-غشت اللي قد يحتاجو سقي زايد، وخطط جداول الحصاد على حساب هادشي.`;
    }
    
    if (messageLower.includes("soil") || messageLower.includes("ground") || messageLower.includes("turba") || messageLower.includes("ard") ||
        messageLower.includes("تربة") || messageLower.includes("أرض")) {
      return `الأرض ديالك عندها ${land.soilType}، اللي ممتازة لزراعة ${crop}. هاد النوع ديال التربة كيعطي تصريف مزيان مع الاحتفاظ بماء كافي لنمو صحي ديال النبتة.

للنتائج المثالية مع ${crop} في هاد التربة:

1. زيد مواد عضوية كل عام باش تحسن بنية وخصب ديال التربة
2. راقب مستويات pH - هدف ل 6.0-7.0 لمعظم المزروعات
3. فكر في زيادة مولش باش تحافظ على رطوبة وتقلل من الأعشاب الضارة
4. طبق دورات زراعية باش تحمي من الأمراض اللي كتنقل عبر التربة

التربة ديالك غنية بالبوتاسيوم، اللي كيساعد نمو الفاكهة في ${crop}.`;
    }
    
    if (messageLower.includes("harvest") || messageLower.includes("yield") || messageLower.includes("hsad") || messageLower.includes("glla") ||
        messageLower.includes("حصاد") || messageLower.includes("غلة") || messageLower.includes("محصول") || messageLower.includes("إنتاج")) {
      if (crop === "Tomatoes") {
        return `الطماطم في ${land.region} ب ${land.surfaceArea}، يمكن تتوقع إنتاج تقريباً 40-60 طن لكل هكتار مع ممارسات تدبير مزيانة.

الحصاد عادة كيبدا 70-90 يوم من بعد نقل الشتلات، على حساب النوع. الأنواع غير محددة غادي يعطيو المنتوج بشكل مستمر لعدة شهور.

لأفضل جودة، حصد منين تكون الطماطم قاصة وملونة بالكامل ولكن مازال فيها شوية ديال القساوة في المس. الحصاد في الصباح كيعطي أفضل مذاق ومدة صلاحية أطول.`;
      } else if (crop === "Citrus") {
        return `إنتاج الليمون في ${land.region} بمعدل 20-30 طن لكل هكتار للبساتين الناضجة. الشجر كيبداو يعطيو كميات تجارية في عام 3-4، وإنتاج كامل في عام 7-8.

توقيت الحصاد كيعتمد على نوع الليمون، ولكن عادة كيجي من نونبر لمارس. الفاكهة خص تتحصد منين توصل للحجم واللون كاملين، وتكون عندها نسبة سكر-حمض مناسبة لنوعها.`;
      } else if (crop === "Olives") {
        return `إنتاج الزيتون في ${land.region} بتربة ${land.soilType} ديالك يمكن يكون بين 3-10 طن لكل هكتار، على حساب النوع والممارسات تدبير.

الحصاد عادة كيجي من أكتوبر ليناير. لإنتاج الزيت، الزيتون كيتحصد منين كيتبدل من الأخضر للأرجواني. لزيتون المائدة، التوقيت كيعتمد على الستيل اللي مرغوب (أخضر ولا كحل).

طرق الحصاد الحديثة كتشمل هزازات ميكانيكية ولا مشطات يدوية اللي كيقللو من ضرر الشجر والفاكهة.`;
      }
    }
    
    if (messageLower.includes("market") || messageLower.includes("sell") || messageLower.includes("price") || messageLower.includes("suq") || messageLower.includes("bi3") || messageLower.includes("taman") ||
        messageLower.includes("سوق") || messageLower.includes("بيع") || messageLower.includes("ثمن") || messageLower.includes("سعر")) {
      return `${crop} من منطقة ${land.region} عندهم قيمة عالية في أسواق محلية وتصدير. أسعار السوق حالياً بين 2-5 درهم/كلغ على حساب جودة ووقت الموسم.

فكر في هاد قنوات التسويق:

1. بيع مباشر لأسواق محلية ومطاعم
2. الانضمام لتعاونية للبيع بالجملة وقدرة تفاوض أحسن
3. فرص تصدير، خصوصاً للمنتجات عضوية ولا أنواع خاصة
4. تزييد القيمة (منتجات مجففة، محفوظة، ولا محولة)

شهادة المنتج العضوي تقدر تزيد الأسعار ب 30-50%، ولكين كتحتاج لفترة تحويل 3 سنين والالتزام بمعايير صارمة.`;
    }
    
    // Default response if no specific match
    return `شكراً على سؤالك على "${message}". بصفتي مساعد زراعي ديالك، نقدر نعطيك معلومات مفصلة على اختيار المزروعات، طرق السقي، تدبير الآفات، وممارسات الفلاحة خاصة بمنطقتك ${land.region}.

ل ${crop} اللي اختاريتي والأرض ديالك بتربة ${land.soilType}، كننصحك تشوف دلائل مفصلة في قسم الموارد. يمكن ليك تسأل سؤال معين على وقت الزراعة، الوقاية من الأمراض، احتياجات السقي، ولا تحسين الإنتاج.`;
  }
}

export const storage = new MemStorage();
